<?php

$response=array();

if($_SERVER['REQUEST_METHOD']=='GET')
{
        if(isset($_GET['TYPE'])){
                include_once 'Constants.php';
                $con=new mysqli(DB_HOST,DB_USER,DB_PASSWORD,DB_NAME);
                
            // Check connection
                if ($conn->connect_error) 
                {
                        die("Connection failed: " . $conn->connect_error);
                }
        
                $con->query('SET CHARACTER SET utf8');
        
            if($_GET['TYPE']=="makeup")
            {
                $stmt=$con->query("SELECT * FROM items WHERE category='makeup'");

            }
            else if($_GET['TYPE']=="accessories")
            {
                $stmt=$con->query("SELECT * FROM items WHERE category='accessories'");

            }
            else if($_GET['TYPE']=="perfumes")
            {
                $stmt=$con->query("SELECT * FROM items WHERE category='perfumes'");

            }
            else if($_GET['TYPE']=="clothes")
            {
                $stmt=$con->query("SELECT * FROM items WHERE category='clothes'");

            }
            else if($_GET['TYPE']=="shoes")
            {
                $stmt=$con->query("SELECT * FROM items WHERE category='shoes'");

            }
            else if($_GET['TYPE']=="offers")
            {
                $stmt=$con->query("SELECT * FROM items WHERE category='offers'");

            }
            else
            {
                http_response_code(404); 
            }
                while($row = $stmt -> fetch_assoc())
                {
                         array_push($response,$row);
                } 

                
                echo json_encode($response);
                $con -> close();
        }
        else
        {
         http_response_code(404); 
        }


}
else
{
	// Get the current response code and set a new one
        http_response_code(404); 
}



?>