<?php 
define('DB_NAME','3331719_beautyhome');
define('DB_USER','3331719_beautyhome');
define('DB_PASSWORD','BeautyHomeSheikhBadr123');
define('DB_HOST','fdb24.awardspace.net');
?>